// const assert = require('chai').assert
// const app = require('../../todolist copy 3/main')

// describe('Main', function(){
//     it('app should update list', function()){
//         assert.equal(main(updateList));
//     }
// })
